# Vector 3D Scan v1.3

Small-object scanner for 3D printing.

V1.3 changes the acquisition engine to dense ARCore Depth first (Raw Depth refinement/fallback), uses 2.5 mm voxels, adds live distance guidance, 360-degree coverage guidance, scale calibration from a real caliper measurement, print-readiness checks, cleaned watertight voxel STL export, and PLY export.
