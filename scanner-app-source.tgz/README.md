# Vector 3D Scan v1.1

Android on-device 3D scanner MVP.

Changes in v1.1:
- central small-part ROI
- 240 mm metric capture cube around target
- connected-component cleanup
- isolated voxel removal
- STL/PLY normalization to positive coordinates and Z=0
- ARCore Depth with sparse feature fallback
