# Vector 3D Scan v1.2

Android on-device 3D scanner with ARCore Depth.

V1.2 adds live user feedback: quality traffic light, coverage estimate, movement warning, changing reticle color, and haptic confirmation when a new viewing sector is captured.
