package com.vector.scan3d

import android.media.Image
import com.google.ar.core.Frame
import com.google.ar.core.Pose
import com.google.ar.core.exceptions.NotYetAvailableException
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Small-object 3D fusion optimized for printable scans.
 *
 * V1.3 uses ARCore's dense Depth image first because Raw Depth is intentionally sparse.
 * Raw Depth is retained as a precision/fallback source and ARCore feature points are the last fallback.
 * All geometry is fused in an anchor-stable metric voxel grid.
 */
class PointCloudFusion(
    private val voxelSizeM: Float = 0.0025f,
    private val confidenceThreshold: Int = 55,
    private val maxVoxels: Int = 320_000
) {
    enum class Source { DENSE_DEPTH, RAW_DEPTH, FEATURE_POINTS, NONE }

    data class IntegrateResult(
        val added: Int,
        val distanceMm: Int,
        val source: Source,
        val hasDepth: Boolean
    )

    data class Stats(
        val voxels: Int,
        val widthMm: Float,
        val heightMm: Float,
        val depthMm: Float,
        val depthFrames: Int,
        val scaleFactor: Float
    )

    private data class Voxel(
        val qx: Int,
        val qy: Int,
        val qz: Int,
        var sx: Float = 0f,
        var sy: Float = 0f,
        var sz: Float = 0f,
        var count: Int = 0
    ) {
        fun add(x: Float, y: Float, z: Float) {
            sx += x; sy += y; sz += z; count++
        }
        fun center(): FloatArray = if (count == 0) floatArrayOf(0f, 0f, 0f)
        else floatArrayOf(sx / count, sy / count, sz / count)
    }

    private val voxels = HashMap<Long, Voxel>(65_536)
    private var lastDenseDepthTimestamp = -1L
    private var lastRawDepthTimestamp = -1L
    private var lastPointCloudTimestamp = -1L
    private var depthFrames = 0
    private var targetInAnchor: FloatArray? = null
    private var lastDistanceMm = -1
    private var currentScale = 1f

    @Synchronized
    fun clear() {
        voxels.clear()
        lastDenseDepthTimestamp = -1L
        lastRawDepthTimestamp = -1L
        lastPointCloudTimestamp = -1L
        depthFrames = 0
        targetInAnchor = null
        lastDistanceMm = -1
        currentScale = 1f
    }

    /** Dense Depth is the primary source for small objects. */
    @Synchronized
    fun integrateHybridDepth(frame: Frame, anchorPose: Pose): IntegrateResult {
        if (voxels.size >= maxVoxels) return IntegrateResult(0, lastDistanceMm, Source.NONE, true)

        val dense = integrateDenseDepth(frame, anchorPose)
        if (dense.hasDepth && (dense.added > 0 || dense.distanceMm > 0)) return dense

        val raw = integrateRawDepth(frame, anchorPose)
        if (raw.hasDepth && (raw.added > 0 || raw.distanceMm > 0)) return raw

        val featureAdded = integrateFeaturePoints(frame, anchorPose)
        return IntegrateResult(featureAdded, lastDistanceMm, if (featureAdded > 0) Source.FEATURE_POINTS else Source.NONE, false)
    }

    /**
     * Dense, temporally-filtered depth. A 2D continuity flood-fill is used to isolate the object
     * around the reticle and reject most of the table/background before points enter the 3D grid.
     */
    private fun integrateDenseDepth(frame: Frame, anchorPose: Pose): IntegrateResult {
        try {
            frame.acquireDepthImage16Bits().use { depth ->
                if (depth.timestamp == lastDenseDepthTimestamp) {
                    return IntegrateResult(0, lastDistanceMm, Source.DENSE_DEPTH, true)
                }
                lastDenseDepthTimestamp = depth.timestamp

                val centerDepthMm = estimateCenterDepthDense(depth)
                if (centerDepthMm <= 0) return IntegrateResult(0, -1, Source.DENSE_DEPTH, true)
                lastDistanceMm = centerDepthMm

                val camera = frame.camera
                val intr = camera.imageIntrinsics
                val dims = intr.imageDimensions
                val fx = intr.focalLength[0] * depth.width.toFloat() / dims[0].toFloat()
                val fy = intr.focalLength[1] * depth.height.toFloat() / dims[1].toFloat()
                val cx = intr.principalPoint[0] * depth.width.toFloat() / dims[0].toFloat()
                val cy = intr.principalPoint[1] * depth.height.toFloat() / dims[1].toFloat()
                if (fx <= 1f || fy <= 1f) return IntegrateResult(0, centerDepthMm, Source.DENSE_DEPTH, true)

                val cameraPose = camera.pose
                val worldToAnchor = anchorPose.inverse()
                ensureTarget(centerDepthMm, depth.width, depth.height, fx, fy, cx, cy, cameraPose, worldToAnchor)
                val target = targetInAnchor ?: return IntegrateResult(0, centerDepthMm, Source.DENSE_DEPTH, true)

                val plane = depth.planes[0]
                val buf = plane.buffer.duplicate()

                // Center ROI is deliberately generous; flood-fill does the actual object separation.
                val x0 = depth.width / 7
                val x1 = depth.width * 6 / 7
                val y0 = depth.height / 8
                val y1 = depth.height * 7 / 8
                val step = if (depth.width >= 480) 3 else 2
                val gw = max(1, (x1 - x0 + step - 1) / step)
                val gh = max(1, (y1 - y0 + step - 1) / step)
                val samples = IntArray(gw * gh)

                for (gy in 0 until gh) {
                    val y = min(y1 - 1, y0 + gy * step)
                    for (gx in 0 until gw) {
                        val x = min(x1 - 1, x0 + gx * step)
                        val d = getU16(buf, plane.rowStride, plane.pixelStride, x, y)
                        if (d in MIN_DEPTH_MM..MAX_DEPTH_MM && abs(d - centerDepthMm) <= OBJECT_DEPTH_WINDOW_MM) {
                            samples[gy * gw + gx] = d
                        }
                    }
                }

                // Seed from the grid cell closest to the screen center; search a small neighborhood if empty.
                val seedGX0 = ((depth.width / 2 - x0) / step).coerceIn(0, gw - 1)
                val seedGY0 = ((depth.height / 2 - y0) / step).coerceIn(0, gh - 1)
                var seed = -1
                outer@ for (r in 0..4) {
                    for (dy in -r..r) for (dx in -r..r) {
                        val gx = seedGX0 + dx; val gy = seedGY0 + dy
                        if (gx !in 0 until gw || gy !in 0 until gh) continue
                        val idx = gy * gw + gx
                        if (samples[idx] > 0) { seed = idx; break@outer }
                    }
                }
                if (seed < 0) return IntegrateResult(0, centerDepthMm, Source.DENSE_DEPTH, true)

                val visited = BooleanArray(samples.size)
                val queue = java.util.ArrayDeque<Int>()
                visited[seed] = true; queue.add(seed)
                var accepted = 0
                while (queue.isNotEmpty() && voxels.size < maxVoxels) {
                    val idx = queue.removeFirst()
                    val dMm = samples[idx]
                    if (dMm <= 0) continue
                    val gx = idx % gw; val gy = idx / gw
                    val x = min(x1 - 1, x0 + gx * step)
                    val y = min(y1 - 1, y0 + gy * step)

                    val z = dMm / 1000f
                    val local = floatArrayOf(
                        (x - cx) * z / fx,
                        -(y - cy) * z / fy,
                        -z
                    )
                    val world = cameraPose.transformPoint(local)
                    val p = worldToAnchor.transformPoint(world)
                    val px = p[0] - target[0]
                    val py = p[1] - target[1]
                    val pz = p[2] - target[2]
                    if (abs(px) <= CAPTURE_HALF_M && abs(py) <= CAPTURE_HALF_M && abs(pz) <= CAPTURE_HALF_M) {
                        addPoint(px, py, pz)
                        accepted++
                    }

                    val nbs = intArrayOf(idx - 1, idx + 1, idx - gw, idx + gw)
                    for (n in nbs) {
                        if (n !in samples.indices || visited[n]) continue
                        val ngx = n % gw; val ngy = n / gw
                        if (abs(ngx - gx) + abs(ngy - gy) != 1) continue // prevents row wrap
                        val nd = samples[n]
                        if (nd <= 0) continue
                        if (abs(nd - dMm) <= LOCAL_CONTINUITY_MM && abs(nd - centerDepthMm) <= OBJECT_DEPTH_WINDOW_MM) {
                            visited[n] = true
                            queue.add(n)
                        }
                    }
                }

                if (accepted > 0) depthFrames++
                return IntegrateResult(accepted, centerDepthMm, Source.DENSE_DEPTH, true)
            }
        } catch (_: NotYetAvailableException) {
            return IntegrateResult(0, -1, Source.DENSE_DEPTH, true)
        } catch (_: Exception) {
            return IntegrateResult(0, -1, Source.DENSE_DEPTH, true)
        }
    }

    /** Raw Depth refinement/fallback when dense Depth is not yet yielding usable geometry. */
    private fun integrateRawDepth(frame: Frame, anchorPose: Pose): IntegrateResult {
        try {
            frame.acquireRawDepthImage16Bits().use { depth ->
                if (depth.timestamp == lastRawDepthTimestamp) return IntegrateResult(0, lastDistanceMm, Source.RAW_DEPTH, true)
                frame.acquireRawDepthConfidenceImage().use { confidence ->
                    lastRawDepthTimestamp = depth.timestamp
                    val centerDepthMm = estimateCenterDepthRaw(depth, confidence)
                    if (centerDepthMm <= 0) return IntegrateResult(0, -1, Source.RAW_DEPTH, true)
                    lastDistanceMm = centerDepthMm

                    val camera = frame.camera
                    val intr = camera.imageIntrinsics
                    val dims = intr.imageDimensions
                    val fx = intr.focalLength[0] * depth.width.toFloat() / dims[0].toFloat()
                    val fy = intr.focalLength[1] * depth.height.toFloat() / dims[1].toFloat()
                    val cx = intr.principalPoint[0] * depth.width.toFloat() / dims[0].toFloat()
                    val cy = intr.principalPoint[1] * depth.height.toFloat() / dims[1].toFloat()
                    val cameraPose = camera.pose
                    val worldToAnchor = anchorPose.inverse()
                    ensureTarget(centerDepthMm, depth.width, depth.height, fx, fy, cx, cy, cameraPose, worldToAnchor)
                    val target = targetInAnchor ?: return IntegrateResult(0, centerDepthMm, Source.RAW_DEPTH, true)

                    val dp = depth.planes[0]; val cp = confidence.planes[0]
                    val db = dp.buffer.duplicate(); val cb = cp.buffer.duplicate()
                    val x0 = depth.width / 5; val x1 = depth.width * 4 / 5
                    val y0 = depth.height / 6; val y1 = depth.height * 5 / 6
                    val step = if (depth.width >= 320) 3 else 2
                    var accepted = 0
                    var y = y0
                    while (y < y1 && voxels.size < maxVoxels) {
                        var x = x0
                        while (x < x1 && voxels.size < maxVoxels) {
                            val conf = getU8(cb, cp.rowStride, cp.pixelStride, x, y)
                            if (conf >= confidenceThreshold) {
                                val dMm = getU16(db, dp.rowStride, dp.pixelStride, x, y)
                                if (dMm in MIN_DEPTH_MM..MAX_DEPTH_MM && abs(dMm - centerDepthMm) <= OBJECT_DEPTH_WINDOW_MM) {
                                    val z = dMm / 1000f
                                    val local = floatArrayOf((x-cx)*z/fx, -(y-cy)*z/fy, -z)
                                    val world = cameraPose.transformPoint(local)
                                    val p = worldToAnchor.transformPoint(world)
                                    val px=p[0]-target[0]; val py=p[1]-target[1]; val pz=p[2]-target[2]
                                    if (abs(px)<=CAPTURE_HALF_M && abs(py)<=CAPTURE_HALF_M && abs(pz)<=CAPTURE_HALF_M) {
                                        addPoint(px,py,pz); accepted++
                                    }
                                }
                            }
                            x += step
                        }
                        y += step
                    }
                    if (accepted > 0) depthFrames++
                    return IntegrateResult(accepted, centerDepthMm, Source.RAW_DEPTH, true)
                }
            }
        } catch (_: NotYetAvailableException) {
            return IntegrateResult(0, -1, Source.RAW_DEPTH, true)
        } catch (_: Exception) {
            return IntegrateResult(0, -1, Source.RAW_DEPTH, true)
        }
    }

    private fun ensureTarget(
        centerDepthMm: Int, width: Int, height: Int, fx: Float, fy: Float, cx: Float, cy: Float,
        cameraPose: Pose, worldToAnchor: Pose
    ) {
        if (targetInAnchor != null) return
        val z0 = centerDepthMm / 1000f
        val centerLocal = floatArrayOf(
            (width * 0.5f - cx) * z0 / fx,
            -(height * 0.5f - cy) * z0 / fy,
            -z0
        )
        val targetWorld = cameraPose.transformPoint(centerLocal)
        targetInAnchor = worldToAnchor.transformPoint(targetWorld)
    }

    /** Sparse fallback for ARCore devices without usable Depth. */
    private fun integrateFeaturePoints(frame: Frame, anchorPose: Pose): Int {
        try {
            frame.acquirePointCloud().use { cloud ->
                if (cloud.timestamp == lastPointCloudTimestamp) return 0
                lastPointCloudTimestamp = cloud.timestamp
                val worldToAnchor = anchorPose.inverse()
                val points = cloud.points
                var added = 0
                while (points.remaining() >= 4 && voxels.size < maxVoxels) {
                    val x=points.get(); val y=points.get(); val z=points.get(); val confidence=points.get()
                    if (confidence >= 0.65f) {
                        val p=worldToAnchor.transformPoint(floatArrayOf(x,y,z))
                        if (abs(p[0])<0.7f && abs(p[1])<0.7f && abs(p[2])<0.7f) { addPoint(p[0],p[1],p[2]); added++ }
                    }
                }
                return added
            }
        } catch (_: Exception) { return 0 }
    }

    @Synchronized fun pointCount(): Int = voxels.size
    @Synchronized fun targetPositionInAnchor(): FloatArray? = targetInAnchor?.clone()
    @Synchronized fun latestDistanceMm(): Int = lastDistanceMm

    @Synchronized
    fun stats(): Stats {
        if (voxels.isEmpty()) return Stats(0,0f,0f,0f,depthFrames,currentScale)
        var minX=Float.POSITIVE_INFINITY; var minY=Float.POSITIVE_INFINITY; var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY; var maxY=Float.NEGATIVE_INFINITY; var maxZ=Float.NEGATIVE_INFINITY
        for (v in voxels.values) {
            val p=v.center()
            minX=min(minX,p[0]); maxX=max(maxX,p[0])
            minY=min(minY,p[1]); maxY=max(maxY,p[1])
            minZ=min(minZ,p[2]); maxZ=max(maxZ,p[2])
        }
        return Stats(
            voxels.size,
            (maxX-minX)*1000f*currentScale,
            (maxY-minY)*1000f*currentScale,
            (maxZ-minZ)*1000f*currentScale,
            depthFrames,
            currentScale
        )
    }

    /** Calibrate global scale from one known X/Y/Z dimension measured with a caliper. */
    @Synchronized
    fun calibrate(axis: Char, actualMm: Float): Boolean {
        if (actualMm <= 0f || voxels.isEmpty()) return false
        val s = rawStats()
        val current = when(axis.uppercaseChar()) { 'X' -> s[0]; 'Y' -> s[1]; else -> s[2] }
        if (current <= 0.01f) return false
        currentScale = (actualMm / current).coerceIn(0.1f, 10f)
        return true
    }

    private fun rawStats(): FloatArray {
        var minX=Float.POSITIVE_INFINITY; var minY=Float.POSITIVE_INFINITY; var minZ=Float.POSITIVE_INFINITY
        var maxX=Float.NEGATIVE_INFINITY; var maxY=Float.NEGATIVE_INFINITY; var maxZ=Float.NEGATIVE_INFINITY
        for (v in voxels.values) {
            val p=v.center(); minX=min(minX,p[0]); maxX=max(maxX,p[0]); minY=min(minY,p[1]); maxY=max(maxY,p[1]); minZ=min(minZ,p[2]); maxZ=max(maxZ,p[2])
        }
        return floatArrayOf((maxX-minX)*1000f,(maxY-minY)*1000f,(maxZ-minZ)*1000f)
    }

    /** Removes speckles and keeps the dominant connected component nearest the target. */
    private fun cleanedSolid(): HashSet<Long> {
        val candidate=HashSet<Long>(voxels.size)
        for (v in voxels.values) {
            var neighbors=0
            for (d in DIRS) if (voxels.containsKey(key(v.qx+d[0],v.qy+d[1],v.qz+d[2]))) neighbors++
            if (neighbors>=1 || v.count>=2) candidate.add(key(v.qx,v.qy,v.qz))
        }
        if (candidate.isEmpty()) candidate.addAll(voxels.keys)
        if (candidate.isEmpty()) return candidate

        val visited=HashSet<Long>(candidate.size); val components=ArrayList<HashSet<Long>>()
        for (start in candidate) {
            if (!visited.add(start)) continue
            val comp=HashSet<Long>(); val q=java.util.ArrayDeque<Long>(); q.add(start)
            while(q.isNotEmpty()) {
                val k=q.removeFirst(); comp.add(k); val v=voxels[k] ?: continue
                for (d in DIRS) {
                    val nk=key(v.qx+d[0],v.qy+d[1],v.qz+d[2])
                    if(candidate.contains(nk)&&visited.add(nk)) q.add(nk)
                }
            }
            components.add(comp)
        }
        val largest=components.maxByOrNull{it.size} ?: candidate

        // Fill only strong one-voxel holes/gaps. This helps slicers while limiting geometric inflation.
        val bridged=HashSet<Long>(largest)
        for(k in largest) {
            val v=voxels[k] ?: continue
            for(d in DIRS) {
                val nx=v.qx+d[0]; val ny=v.qy+d[1]; val nz=v.qz+d[2]; val nk=key(nx,ny,nz)
                if(bridged.contains(nk)) continue
                var n=0
                for(dd in DIRS) if(largest.contains(key(nx+dd[0],ny+dd[1],nz+dd[2]))) n++
                if(n>=4) bridged.add(nk)
            }
        }
        return bridged
    }

    private data class Bounds(val minX:Int,val minY:Int,val minZ:Int,val maxX:Int,val maxY:Int,val maxZ:Int)
    private fun boundsOf(solid:Set<Long>):Bounds {
        var minX=Int.MAX_VALUE; var minY=Int.MAX_VALUE; var minZ=Int.MAX_VALUE; var maxX=Int.MIN_VALUE; var maxY=Int.MIN_VALUE; var maxZ=Int.MIN_VALUE
        for(k in solid){ val v=voxels[k] ?: decodeVoxel(k); minX=min(minX,v.qx);minY=min(minY,v.qy);minZ=min(minZ,v.qz);maxX=max(maxX,v.qx);maxY=max(maxY,v.qy);maxZ=max(maxZ,v.qz) }
        return Bounds(minX,minY,minZ,maxX,maxY,maxZ)
    }

    private fun decodeVoxel(k:Long):Voxel {
        fun dec(v:Long)=((v and MASK).toInt()-OFFSET)
        val qx=dec(k ushr 42); val qy=dec(k ushr 21); val qz=dec(k)
        return Voxel(qx,qy,qz)
    }

    @Synchronized
    fun exportPly(file:File) {
        file.parentFile?.mkdirs(); val solid=cleanedSolid(); if(solid.isEmpty()) return; val b=boundsOf(solid); val h=voxelSizeM*500f*currentScale
        file.bufferedWriter().use { out ->
            out.appendLine("ply");out.appendLine("format ascii 1.0");out.appendLine("comment Vector 3D Scan v1.3 cleaned metric point cloud");out.appendLine("element vertex ${solid.size}");out.appendLine("property float x");out.appendLine("property float y");out.appendLine("property float z");out.appendLine("end_header")
            for(k in solid){ val v=voxels[k] ?: decodeVoxel(k); val x=(v.qx-b.minX)*voxelSizeM*1000f*currentScale+h; val y=(v.qy-b.minY)*voxelSizeM*1000f*currentScale+h; val z=(v.qz-b.minZ)*voxelSizeM*1000f*currentScale+h; out.append(String.format(Locale.US,"%.3f %.3f %.3f\n",x,y,z)) }
        }
    }

    @Synchronized
    fun exportStl(file:File) {
        file.parentFile?.mkdirs(); val solid=cleanedSolid(); if(solid.isEmpty()) return; val b=boundsOf(solid)
        var triangles=0L
        for(k in solid){ val v=voxels[k] ?: decodeVoxel(k); for(d in DIRS) if(!solid.contains(key(v.qx+d[0],v.qy+d[1],v.qz+d[2]))) triangles+=2 }
        val triCount=min(triangles,Int.MAX_VALUE.toLong()).toInt()
        DataOutputStream(BufferedOutputStream(FileOutputStream(file))).use { out ->
            val header=ByteArray(80); val title="Vector 3D Scan v1.3 - ${voxelSizeM*1000f}mm voxel".toByteArray(Charsets.US_ASCII); System.arraycopy(title,0,header,0,min(title.size,header.size)); out.write(header); writeLeInt(out,triCount)
            val h=voxelSizeM*500f*currentScale; var written=0
            loop@ for(k in solid){ val v=voxels[k] ?: decodeVoxel(k); val c=floatArrayOf((v.qx-b.minX)*voxelSizeM*1000f*currentScale+h,(v.qy-b.minY)*voxelSizeM*1000f*currentScale+h,(v.qz-b.minZ)*voxelSizeM*1000f*currentScale+h)
                for(face in 0 until 6){ val d=DIRS[face]; if(solid.contains(key(v.qx+d[0],v.qy+d[1],v.qz+d[2]))) continue; val verts=faceVertices(c[0],c[1],c[2],h,face); val n=NORMALS[face]; writeTriangle(out,n,verts[0],verts[1],verts[2]);written++;if(written>=triCount)break@loop;writeTriangle(out,n,verts[0],verts[2],verts[3]);written++;if(written>=triCount)break@loop }
            }
        }
    }

    private fun addPoint(x:Float,y:Float,z:Float){ val qx=floor(x/voxelSizeM).toInt();val qy=floor(y/voxelSizeM).toInt();val qz=floor(z/voxelSizeM).toInt();val k=key(qx,qy,qz);val v=voxels[k]?:Voxel(qx,qy,qz).also{voxels[k]=it};v.add(x,y,z) }

    private fun estimateCenterDepthDense(depth:Image):Int {
        val p=depth.planes[0]; val b=p.buffer.duplicate(); val values=ArrayList<Int>(512)
        val xs=depth.width*2/5;val xe=depth.width*3/5;val ys=depth.height*2/5;val ye=depth.height*3/5
        var y=ys;while(y<ye){var x=xs;while(x<xe){val d=getU16(b,p.rowStride,p.pixelStride,x,y);if(d in MIN_DEPTH_MM..MAX_DEPTH_MM)values.add(d);x+=2};y+=2}
        if(values.isEmpty())return -1;values.sort();return values[values.size/2]
    }

    private fun estimateCenterDepthRaw(depth:Image,confidence:Image):Int {
        val dp=depth.planes[0];val cp=confidence.planes[0];val db=dp.buffer.duplicate();val cb=cp.buffer.duplicate();val values=ArrayList<Int>(256)
        val xs=depth.width*3/8;val xe=depth.width*5/8;val ys=depth.height*3/8;val ye=depth.height*5/8
        var y=ys;while(y<ye){var x=xs;while(x<xe){val conf=getU8(cb,cp.rowStride,cp.pixelStride,x,y);if(conf>=35){val d=getU16(db,dp.rowStride,dp.pixelStride,x,y);if(d in MIN_DEPTH_MM..MAX_DEPTH_MM)values.add(d)};x+=2};y+=2}
        if(values.isEmpty())return -1;values.sort();return values[values.size/2]
    }

    private fun getU8(buf:java.nio.ByteBuffer,rowStride:Int,pixelStride:Int,x:Int,y:Int):Int{val pos=y*rowStride+x*pixelStride;return if(pos in 0 until buf.limit())buf.get(pos).toInt() and 0xff else 0}
    private fun getU16(buf:java.nio.ByteBuffer,rowStride:Int,pixelStride:Int,x:Int,y:Int):Int{val pos=y*rowStride+x*pixelStride;if(pos<0||pos+1>=buf.limit())return 0;val lo=buf.get(pos).toInt() and 0xff;val hi=buf.get(pos+1).toInt() and 0xff;return lo or(hi shl 8)}

    private fun key(x:Int,y:Int,z:Int):Long{val ox=(x+OFFSET).toLong() and MASK;val oy=(y+OFFSET).toLong() and MASK;val oz=(z+OFFSET).toLong() and MASK;return(ox shl 42)or(oy shl 21)or oz}
    private fun faceVertices(cx:Float,cy:Float,cz:Float,h:Float,face:Int):Array<FloatArray> = when(face){
        0->arrayOf(floatArrayOf(cx+h,cy-h,cz-h),floatArrayOf(cx+h,cy+h,cz-h),floatArrayOf(cx+h,cy+h,cz+h),floatArrayOf(cx+h,cy-h,cz+h));
        1->arrayOf(floatArrayOf(cx-h,cy-h,cz+h),floatArrayOf(cx-h,cy+h,cz+h),floatArrayOf(cx-h,cy+h,cz-h),floatArrayOf(cx-h,cy-h,cz-h));
        2->arrayOf(floatArrayOf(cx-h,cy+h,cz-h),floatArrayOf(cx-h,cy+h,cz+h),floatArrayOf(cx+h,cy+h,cz+h),floatArrayOf(cx+h,cy+h,cz-h));
        3->arrayOf(floatArrayOf(cx-h,cy-h,cz+h),floatArrayOf(cx-h,cy-h,cz-h),floatArrayOf(cx+h,cy-h,cz-h),floatArrayOf(cx+h,cy-h,cz+h));
        4->arrayOf(floatArrayOf(cx-h,cy-h,cz+h),floatArrayOf(cx+h,cy-h,cz+h),floatArrayOf(cx+h,cy+h,cz+h),floatArrayOf(cx-h,cy+h,cz+h));
        else->arrayOf(floatArrayOf(cx+h,cy-h,cz-h),floatArrayOf(cx-h,cy-h,cz-h),floatArrayOf(cx-h,cy+h,cz-h),floatArrayOf(cx+h,cy+h,cz-h))}
    private fun writeTriangle(out:DataOutputStream,normal:FloatArray,a:FloatArray,b:FloatArray,c:FloatArray){for(v in normal)writeLeFloat(out,v);for(p in arrayOf(a,b,c))for(v in p)writeLeFloat(out,v);writeLeShort(out,0)}
    private fun writeLeFloat(out:OutputStream,v:Float)=writeLeInt(out,java.lang.Float.floatToIntBits(v))
    private fun writeLeInt(out:OutputStream,v:Int){out.write(v and 0xff);out.write((v ushr 8)and 0xff);out.write((v ushr 16)and 0xff);out.write((v ushr 24)and 0xff)}
    private fun writeLeShort(out:OutputStream,v:Int){out.write(v and 0xff);out.write((v ushr 8)and 0xff)}

    companion object {
        private const val OFFSET=1_048_576
        private const val MASK=0x1FFFFFL
        private const val MIN_DEPTH_MM=150
        private const val MAX_DEPTH_MM=1400
        private const val OBJECT_DEPTH_WINDOW_MM=180
        private const val LOCAL_CONTINUITY_MM=55
        private const val CAPTURE_HALF_M=0.22f
        private val DIRS=arrayOf(intArrayOf(1,0,0),intArrayOf(-1,0,0),intArrayOf(0,1,0),intArrayOf(0,-1,0),intArrayOf(0,0,1),intArrayOf(0,0,-1))
        private val NORMALS=arrayOf(floatArrayOf(1f,0f,0f),floatArrayOf(-1f,0f,0f),floatArrayOf(0f,1f,0f),floatArrayOf(0f,-1f,0f),floatArrayOf(0f,0f,1f),floatArrayOf(0f,0f,-1f))
    }
}
