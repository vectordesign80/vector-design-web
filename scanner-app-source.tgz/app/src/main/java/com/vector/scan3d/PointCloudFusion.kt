package com.vector.scan3d

import android.media.Image
import com.google.ar.core.Frame
import com.google.ar.core.exceptions.NotYetAvailableException
import com.google.ar.core.Pose
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight on-device 3D fusion for a practical MVP.
 * Raw Depth is converted to an anchor-stable voxel cloud in metric units.
 */
class PointCloudFusion(
    private val voxelSizeM: Float = 0.005f,
    private val confidenceThreshold: Int = 80,
    private val maxVoxels: Int = 180_000
) {
    data class Stats(
        val voxels: Int,
        val widthMm: Float,
        val heightMm: Float,
        val depthMm: Float,
        val rawDepthFrames: Int
    )

    private data class Voxel(
        val qx: Int,
        val qy: Int,
        val qz: Int,
        var sx: Float = 0f,
        var sy: Float = 0f,
        var sz: Float = 0f,
        var count: Int = 0
    ) {
        fun add(x: Float, y: Float, z: Float) {
            sx += x; sy += y; sz += z; count++
        }
        fun center(): FloatArray = if (count == 0) floatArrayOf(0f, 0f, 0f)
        else floatArrayOf(sx / count, sy / count, sz / count)
    }

    private val voxels = HashMap<Long, Voxel>(32_768)
    private var lastDepthTimestamp = -1L
    private var lastPointCloudTimestamp = -1L
    private var depthFrames = 0

    @Synchronized
    fun clear() {
        voxels.clear()
        lastDepthTimestamp = -1L
        lastPointCloudTimestamp = -1L
        depthFrames = 0
    }

    /** Returns number of points accepted from this depth frame. */
    @Synchronized
    fun integrateRawDepth(frame: Frame, anchorPose: Pose): Int {
        if (voxels.size >= maxVoxels) return 0
        try {
            frame.acquireRawDepthImage16Bits().use { depth ->
                if (depth.timestamp == lastDepthTimestamp) return 0
                frame.acquireRawDepthConfidenceImage().use { confidence ->
                    lastDepthTimestamp = depth.timestamp
                    val camera = frame.camera
                    val intr = camera.imageIntrinsics
                    val dims = intr.imageDimensions
                    val fx = intr.focalLength[0] * depth.width.toFloat() / dims[0].toFloat()
                    val fy = intr.focalLength[1] * depth.height.toFloat() / dims[1].toFloat()
                    val cx = intr.principalPoint[0] * depth.width.toFloat() / dims[0].toFloat()
                    val cy = intr.principalPoint[1] * depth.height.toFloat() / dims[1].toFloat()

                    val centerDepthMm = estimateCenterDepth(depth, confidence)
                    if (centerDepthMm <= 0) return 0
                    val minDepthMm = max(180, centerDepthMm - 220)
                    val maxDepthMm = min(1500, centerDepthMm + 220)
                    val cameraPose = camera.pose
                    val worldToAnchor = anchorPose.inverse()
                    val depthPlane = depth.planes[0]
                    val confPlane = confidence.planes[0]
                    val depthBuf = depthPlane.buffer.duplicate()
                    val confBuf = confPlane.buffer.duplicate()
                    val x0 = depth.width / 12
                    val x1 = depth.width - x0
                    val y0 = depth.height / 12
                    val y1 = depth.height - depth.height / 8
                    val step = if (depth.width >= 320) 4 else 2
                    var accepted = 0

                    var y = y0
                    while (y < y1 && voxels.size < maxVoxels) {
                        var x = x0
                        while (x < x1 && voxels.size < maxVoxels) {
                            val conf = getU8(confBuf, confPlane.rowStride, confPlane.pixelStride, x, y)
                            if (conf >= confidenceThreshold) {
                                val dMm = getU16(depthBuf, depthPlane.rowStride, depthPlane.pixelStride, x, y)
                                if (dMm in minDepthMm..maxDepthMm) {
                                    val z = dMm / 1000f
                                    // Native camera image coordinates: X right, Y image-down, camera forward is -Z.
                                    val local = floatArrayOf(
                                        (x - cx) * z / fx,
                                        -(y - cy) * z / fy,
                                        -z
                                    )
                                    val world = cameraPose.transformPoint(local)
                                    val p = worldToAnchor.transformPoint(world)
                                    addPoint(p[0], p[1], p[2])
                                    accepted++
                                }
                            }
                            x += step
                        }
                        y += step
                    }
                    if (accepted > 0) depthFrames++
                    return accepted
                }
            }
        } catch (_: NotYetAvailableException) {
            return 0
        } catch (_: Exception) {
            return 0
        }
    }

    /** Sparse fallback for ARCore devices without Depth. */
    @Synchronized
    fun integrateFeaturePoints(frame: Frame, anchorPose: Pose): Int {
        try {
            frame.acquirePointCloud().use { cloud ->
                if (cloud.timestamp == lastPointCloudTimestamp) return 0
                lastPointCloudTimestamp = cloud.timestamp
                val worldToAnchor = anchorPose.inverse()
                val points = cloud.points
                var added = 0
                while (points.remaining() >= 4 && voxels.size < maxVoxels) {
                    val x = points.get(); val y = points.get(); val z = points.get(); val confidence = points.get()
                    if (confidence >= 0.55f) {
                        val p = worldToAnchor.transformPoint(floatArrayOf(x, y, z))
                        val r2 = p[0]*p[0] + p[1]*p[1] + p[2]*p[2]
                        if (r2 < 2.25f) { addPoint(p[0], p[1], p[2]); added++ }
                    }
                }
                return added
            }
        } catch (_: Exception) {
            return 0
        }
    }

    @Synchronized
    fun pointCount(): Int = voxels.size

    @Synchronized
    fun stats(): Stats {
        if (voxels.isEmpty()) return Stats(0, 0f, 0f, 0f, depthFrames)
        var minX = Float.POSITIVE_INFINITY; var minY = Float.POSITIVE_INFINITY; var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY; var maxY = Float.NEGATIVE_INFINITY; var maxZ = Float.NEGATIVE_INFINITY
        for (v in voxels.values) {
            val p = v.center()
            minX = min(minX, p[0]); maxX = max(maxX, p[0])
            minY = min(minY, p[1]); maxY = max(maxY, p[1])
            minZ = min(minZ, p[2]); maxZ = max(maxZ, p[2])
        }
        return Stats(voxels.size, (maxX-minX)*1000f, (maxY-minY)*1000f, (maxZ-minZ)*1000f, depthFrames)
    }

    @Synchronized
    fun exportPly(file: File) {
        file.parentFile?.mkdirs()
        file.bufferedWriter().use { out ->
            out.appendLine("ply")
            out.appendLine("format ascii 1.0")
            out.appendLine("comment Vector 3D Scan metric point cloud")
            out.appendLine("element vertex ${voxels.size}")
            out.appendLine("property float x")
            out.appendLine("property float y")
            out.appendLine("property float z")
            out.appendLine("end_header")
            for (v in voxels.values) {
                val p = v.center()
                out.append(String.format(Locale.US, "%.3f %.3f %.3f\n", p[0]*1000f, p[1]*1000f, p[2]*1000f))
            }
        }
    }

    /**
     * Exports a binary STL surface made from occupied 5 mm voxels.
     * It is deliberately simple and robust enough to be printable / editable as an MVP.
     */
    @Synchronized
    fun exportStl(file: File) {
        file.parentFile?.mkdirs()
        val solid = HashSet<Long>(voxels.size)
        // Remove isolated noise: keep voxels that have at least one direct neighbor.
        for (v in voxels.values) {
            var neighbors = 0
            for (d in DIRS) if (voxels.containsKey(key(v.qx+d[0], v.qy+d[1], v.qz+d[2]))) neighbors++
            if (neighbors >= 1 || v.count >= 3) solid.add(key(v.qx, v.qy, v.qz))
        }
        if (solid.isEmpty()) solid.addAll(voxels.keys)

        var triangles = 0L
        for (k in solid) {
            val v = voxels[k] ?: continue
            for (d in DIRS) if (!solid.contains(key(v.qx+d[0], v.qy+d[1], v.qz+d[2]))) triangles += 2
        }
        val triCount = min(triangles, Int.MAX_VALUE.toLong()).toInt()

        DataOutputStream(BufferedOutputStream(FileOutputStream(file))).use { out ->
            val header = ByteArray(80)
            val title = "Vector 3D Scan STL - voxel ${voxelSizeM*1000f}mm".toByteArray(Charsets.US_ASCII)
            System.arraycopy(title, 0, header, 0, min(title.size, header.size))
            out.write(header)
            writeLeInt(out, triCount)
            val h = voxelSizeM * 500f // half voxel in mm
            var written = 0
            loop@ for (k in solid) {
                val v = voxels[k] ?: continue
                val c = floatArrayOf(v.qx*voxelSizeM*1000f, v.qy*voxelSizeM*1000f, v.qz*voxelSizeM*1000f)
                for (face in 0 until 6) {
                    val d = DIRS[face]
                    if (solid.contains(key(v.qx+d[0], v.qy+d[1], v.qz+d[2]))) continue
                    val verts = faceVertices(c[0], c[1], c[2], h, face)
                    val n = NORMALS[face]
                    writeTriangle(out, n, verts[0], verts[1], verts[2]); written++
                    if (written >= triCount) break@loop
                    writeTriangle(out, n, verts[0], verts[2], verts[3]); written++
                    if (written >= triCount) break@loop
                }
            }
        }
    }

    private fun addPoint(x: Float, y: Float, z: Float) {
        val qx = kotlin.math.floor(x / voxelSizeM).toInt()
        val qy = kotlin.math.floor(y / voxelSizeM).toInt()
        val qz = kotlin.math.floor(z / voxelSizeM).toInt()
        val k = key(qx, qy, qz)
        val v = voxels[k] ?: Voxel(qx, qy, qz).also { voxels[k] = it }
        v.add(x, y, z)
    }

    private fun estimateCenterDepth(depth: Image, confidence: Image): Int {
        val dp = depth.planes[0]; val cp = confidence.planes[0]
        val db = dp.buffer.duplicate(); val cb = cp.buffer.duplicate()
        val xs = depth.width * 3 / 8; val xe = depth.width * 5 / 8
        val ys = depth.height * 3 / 8; val ye = depth.height * 5 / 8
        val values = ArrayList<Int>(256)
        var y = ys
        while (y < ye) {
            var x = xs
            while (x < xe) {
                val conf = getU8(cb, cp.rowStride, cp.pixelStride, x, y)
                if (conf >= 50) {
                    val d = getU16(db, dp.rowStride, dp.pixelStride, x, y)
                    if (d in 180..1500) values.add(d)
                }
                x += 3
            }
            y += 3
        }
        if (values.isEmpty()) return -1
        values.sort()
        return values[values.size / 2]
    }

    private fun getU8(buf: java.nio.ByteBuffer, rowStride: Int, pixelStride: Int, x: Int, y: Int): Int {
        val pos = y * rowStride + x * pixelStride
        return if (pos in 0 until buf.limit()) buf.get(pos).toInt() and 0xff else 0
    }

    private fun getU16(buf: java.nio.ByteBuffer, rowStride: Int, pixelStride: Int, x: Int, y: Int): Int {
        val pos = y * rowStride + x * pixelStride
        if (pos < 0 || pos + 1 >= buf.limit()) return 0
        val lo = buf.get(pos).toInt() and 0xff
        val hi = buf.get(pos + 1).toInt() and 0xff
        return lo or (hi shl 8)
    }

    private fun key(x: Int, y: Int, z: Int): Long {
        val ox = (x + OFFSET).toLong() and MASK
        val oy = (y + OFFSET).toLong() and MASK
        val oz = (z + OFFSET).toLong() and MASK
        return (ox shl 42) or (oy shl 21) or oz
    }

    private fun faceVertices(cx: Float, cy: Float, cz: Float, h: Float, face: Int): Array<FloatArray> = when(face) {
        0 -> arrayOf(floatArrayOf(cx+h,cy-h,cz-h), floatArrayOf(cx+h,cy+h,cz-h), floatArrayOf(cx+h,cy+h,cz+h), floatArrayOf(cx+h,cy-h,cz+h))
        1 -> arrayOf(floatArrayOf(cx-h,cy-h,cz+h), floatArrayOf(cx-h,cy+h,cz+h), floatArrayOf(cx-h,cy+h,cz-h), floatArrayOf(cx-h,cy-h,cz-h))
        2 -> arrayOf(floatArrayOf(cx-h,cy+h,cz-h), floatArrayOf(cx-h,cy+h,cz+h), floatArrayOf(cx+h,cy+h,cz+h), floatArrayOf(cx+h,cy+h,cz-h))
        3 -> arrayOf(floatArrayOf(cx-h,cy-h,cz+h), floatArrayOf(cx-h,cy-h,cz-h), floatArrayOf(cx+h,cy-h,cz-h), floatArrayOf(cx+h,cy-h,cz+h))
        4 -> arrayOf(floatArrayOf(cx-h,cy-h,cz+h), floatArrayOf(cx+h,cy-h,cz+h), floatArrayOf(cx+h,cy+h,cz+h), floatArrayOf(cx-h,cy+h,cz+h))
        else -> arrayOf(floatArrayOf(cx+h,cy-h,cz-h), floatArrayOf(cx-h,cy-h,cz-h), floatArrayOf(cx-h,cy+h,cz-h), floatArrayOf(cx+h,cy+h,cz-h))
    }

    private fun writeTriangle(out: DataOutputStream, normal: FloatArray, a: FloatArray, b: FloatArray, c: FloatArray) {
        for (v in normal) writeLeFloat(out, v)
        for (p in arrayOf(a,b,c)) for (v in p) writeLeFloat(out, v)
        writeLeShort(out, 0)
    }
    private fun writeLeFloat(out: OutputStream, v: Float) = writeLeInt(out, java.lang.Float.floatToIntBits(v))
    private fun writeLeInt(out: OutputStream, v: Int) { out.write(v and 0xff); out.write((v ushr 8) and 0xff); out.write((v ushr 16) and 0xff); out.write((v ushr 24) and 0xff) }
    private fun writeLeShort(out: OutputStream, v: Int) { out.write(v and 0xff); out.write((v ushr 8) and 0xff) }

    companion object {
        private const val OFFSET = 1_048_576
        private const val MASK = 0x1FFFFFL
        private val DIRS = arrayOf(
            intArrayOf(1,0,0), intArrayOf(-1,0,0), intArrayOf(0,1,0),
            intArrayOf(0,-1,0), intArrayOf(0,0,1), intArrayOf(0,0,-1)
        )
        private val NORMALS = arrayOf(
            floatArrayOf(1f,0f,0f), floatArrayOf(-1f,0f,0f), floatArrayOf(0f,1f,0f),
            floatArrayOf(0f,-1f,0f), floatArrayOf(0f,0f,1f), floatArrayOf(0f,0f,-1f)
        )
    }
}
