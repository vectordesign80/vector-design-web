package com.vector.scan3d

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableException
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private var session: Session? = null
    private var installRequested = false
    private lateinit var surfaceView: GLSurfaceView
    private lateinit var renderer: ScanRenderer
    private lateinit var statusText: TextView
    private lateinit var depthText: TextView
    private lateinit var scanButton: Button
    private lateinit var exportStlButton: Button
    private lateinit var exportPlyButton: Button
    private lateinit var dimensionsText: TextView
    private var currentScanDir: File? = null
    private var lastExport: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()

        renderer = ScanRenderer(
            sessionProvider = { session },
            displayRotationProvider = { windowManager.defaultDisplay.rotation },
            onStatus = { msg -> runOnUiThread { statusText.text = msg } },
            onDepthSupport = { supported -> runOnUiThread {
                depthText.text = if (supported) "DEPTH: ACTIVO · reconstrucción métrica" else "DEPTH: NO DISPONIBLE · nube ARCore"
            } }
        )
        surfaceView.setRenderer(renderer)
        surfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        if (!hasCameraPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
        }
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        surfaceView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            preserveEGLContextOnPause = true
        }
        root.addView(surfaceView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 22)
            setBackgroundColor(0x77000000)
        }
        val title = TextView(this).apply {
            text = "VECTOR 3D SCAN"
            setTextColor(Color.WHITE)
            textSize = 21f
        }
        val mode = TextView(this).apply {
            text = "MODO: PIEZA PEQUEÑA · 5 mm"
            setTextColor(0xffdddddd.toInt())
            textSize = 12f
        }
        depthText = TextView(this).apply {
            text = "DEPTH: comprobando…"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        statusText = TextView(this).apply {
            text = "Preparando cámara…"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        dimensionsText = TextView(this).apply {
            visibility = View.GONE
            setTextColor(0xffd8ffd8.toInt())
            textSize = 13f
        }
        top.addView(title); top.addView(mode); top.addView(depthText); top.addView(statusText); top.addView(dimensionsText)
        root.addView(top, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        val reticle = TextView(this).apply {
            text = "+"
            setTextColor(Color.WHITE)
            textSize = 42f
            gravity = Gravity.CENTER
            alpha = 0.75f
        }
        root.addView(reticle, FrameLayout.LayoutParams(90, 90, Gravity.CENTER))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 10, 28, 36)
            setBackgroundColor(0x66000000)
        }
        scanButton = Button(this).apply {
            text = "INICIAR ESCANEO"
            setOnClickListener { toggleScan() }
        }
        exportStlButton = Button(this).apply {
            text = "EXPORTAR STL"
            visibility = View.GONE
            setOnClickListener { exportModel("stl") }
        }
        exportPlyButton = Button(this).apply {
            text = "EXPORTAR PLY"
            visibility = View.GONE
            setOnClickListener { exportModel("ply") }
        }
        val help = TextView(this).apply {
            text = "Pieza pequeña: mantenela dentro del retículo y rodeala lentamente. La app recorta automáticamente 240 mm alrededor del centro."
            setTextColor(0xffeeeeee.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
        }
        bottom.addView(scanButton); bottom.addView(exportStlButton); bottom.addView(exportPlyButton); bottom.addView(help)
        val bp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        root.addView(bottom, bp)
        setContentView(root)
    }

    private fun toggleScan() {
        if (!renderer.scanning) {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val base = getExternalFilesDir("scans") ?: filesDir
            currentScanDir = File(base, "scan_$stamp").apply { mkdirs() }
            lastExport = null
            dimensionsText.visibility = View.GONE
            exportStlButton.visibility = View.GONE
            exportPlyButton.visibility = View.GONE
            renderer.beginScan()
            scanButton.text = "DETENER ESCANEO"
            Toast.makeText(this, "Rodeá la pieza lentamente", Toast.LENGTH_SHORT).show()
        } else {
            renderer.endScan()
            scanButton.text = "INICIAR ESCANEO"
            val stats = renderer.stats()
            dimensionsText.text = "${stats.voxels} vóxeles · aprox. %.0f × %.0f × %.0f mm".format(stats.widthMm, stats.heightMm, stats.depthMm)
            dimensionsText.visibility = View.VISIBLE
            if (stats.voxels > 20) {
                exportStlButton.visibility = View.VISIBLE
                exportPlyButton.visibility = View.VISIBLE
            }
            Toast.makeText(this, "Escaneo detenido: ${stats.voxels} vóxeles", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportModel(format: String) {
        val dir = currentScanDir ?: return
        val points = renderer.pointCount()
        if (points < 20) {
            Toast.makeText(this, "Hay muy pocos puntos. Hacé otro recorrido más lento.", Toast.LENGTH_LONG).show()
            return
        }
        val file = File(dir, if (format == "stl") "vector_scan.stl" else "vector_scan.ply")
        statusText.text = "Generando ${format.uppercase()}…"
        scanButton.isEnabled = false
        exportStlButton.isEnabled = false
        exportPlyButton.isEnabled = false
        thread(name = "export-$format") {
            try {
                if (format == "stl") renderer.exportStl(file) else renderer.exportPly(file)
                lastExport = file
                runOnUiThread {
                    statusText.text = "Archivo listo: ${file.name}"
                    scanButton.isEnabled = true
                    exportStlButton.isEnabled = true
                    exportPlyButton.isEnabled = true
                    shareFile(file)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Error exportando: ${e.message}"
                    scanButton.isEnabled = true
                    exportStlButton.isEnabled = true
                    exportPlyButton.isEnabled = true
                }
            }
        }
    }

    private fun shareFile(file: File) {
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val mime = if (file.extension.lowercase() == "stl") "model/stl" else "application/octet-stream"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartir ${file.name}"))
    }

    override fun onResume() {
        super.onResume()
        if (!hasCameraPermission()) return
        startArSession()
    }

    private fun startArSession() {
        if (session == null) createSession()
        try {
            session?.resume()
            surfaceView.onResume()
        } catch (e: CameraNotAvailableException) {
            statusText.text = "La cámara no está disponible"
            session?.close(); session = null
        }
    }

    private fun createSession() {
        try {
            when (ArCoreApk.getInstance().requestInstall(this, !installRequested)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                    installRequested = true
                    statusText.text = "Instalando/actualizando Servicios de Google Play para RA…"
                    return
                }
                ArCoreApk.InstallStatus.INSTALLED -> Unit
            }
            session = Session(this).also { s ->
                val config = Config(s)
                if (s.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) config.depthMode = Config.DepthMode.AUTOMATIC
                config.focusMode = Config.FocusMode.AUTO
                config.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                s.configure(config)
            }
        } catch (e: UnavailableException) {
            statusText.text = "ARCore no está disponible: ${e.javaClass.simpleName}"
            scanButton.isEnabled = false
        } catch (e: Exception) {
            statusText.text = "No se pudo iniciar ARCore: ${e.message}"
            scanButton.isEnabled = false
        }
    }

    override fun onPause() {
        super.onPause()
        surfaceView.onPause()
        session?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        session?.close(); session = null
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startArSession()
            else statusText.text = "Necesito permiso de cámara para escanear"
        }
    }

    companion object { private const val CAMERA_PERMISSION_CODE = 1001 }
}
