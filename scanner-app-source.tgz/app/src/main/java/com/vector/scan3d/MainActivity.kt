package com.vector.scan3d

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableException
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private var session: Session? = null
    private var installRequested = false
    private lateinit var surfaceView: GLSurfaceView
    private lateinit var renderer: ScanRenderer
    private lateinit var statusText: TextView
    private lateinit var depthText: TextView
    private lateinit var scanButton: Button
    private lateinit var exportStlButton: Button
    private lateinit var exportPlyButton: Button
    private lateinit var calibrateButton: Button
    private lateinit var dimensionsText: TextView
    private lateinit var feedbackBadge: TextView
    private lateinit var instructionText: TextView
    private lateinit var coverageText: TextView
    private lateinit var coverageBar: ProgressBar
    private lateinit var reticle: TextView
    private var currentScanDir: File? = null
    private var lastHapticMs = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()

        renderer = ScanRenderer(
            sessionProvider = { session },
            displayRotationProvider = { windowManager.defaultDisplay.rotation },
            onStatus = { msg -> runOnUiThread { statusText.text = msg } },
            onDepthSupport = { supported -> runOnUiThread {
                depthText.text = if (supported) "DEPTH: DENSO + RAW · métrico" else "DEPTH: no disponible · fallback visual"
            } },
            onFeedback = { feedback -> runOnUiThread { updateFeedback(feedback) } }
        )
        surfaceView.setRenderer(renderer)
        surfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        if (!hasCameraPermission()) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_CODE)
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        surfaceView = GLSurfaceView(this).apply { setEGLContextClientVersion(2); preserveEGLContextOnPause = true }
        root.addView(surfaceView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val top = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,42,28,20); setBackgroundColor(0x88000000.toInt()) }
        val title=TextView(this).apply { text="VECTOR 3D SCAN · V1.3"; setTextColor(Color.WHITE); textSize=21f }
        val mode=TextView(this).apply { text="MODO: OBJETO PARA IMPRESIÓN 3D · 2,5 mm"; setTextColor(0xffdddddd.toInt()); textSize=12f }
        depthText=TextView(this).apply { text="DEPTH: comprobando…"; setTextColor(Color.WHITE); textSize=14f }
        feedbackBadge=TextView(this).apply { text="LISTO PARA ESCANEAR"; setTextColor(Color.WHITE); textSize=15f; gravity=Gravity.CENTER; setPadding(18,10,18,10) }
        setBadgeColor(0xff607d8b.toInt())
        instructionText=TextView(this).apply { text="Poné la pieza en el centro y empezá a 35–70 cm"; setTextColor(0xfff5f5f5.toInt()); textSize=13f; setPadding(0,8,0,5) }
        coverageText=TextView(this).apply { text="Cobertura 0% · esperando geometría"; setTextColor(Color.WHITE); textSize=12f }
        coverageBar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100;progress=0;progressTintList=ColorStateList.valueOf(0xff00e676.toInt());progressBackgroundTintList=ColorStateList.valueOf(0x55ffffff) }
        statusText=TextView(this).apply { text="Preparando cámara…"; setTextColor(0xffcccccc.toInt()); textSize=11f }
        dimensionsText=TextView(this).apply { visibility=View.GONE;setTextColor(0xffd8ffd8.toInt());textSize=13f }
        top.addView(title);top.addView(mode);top.addView(depthText)
        top.addView(feedbackBadge,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply{topMargin=10})
        top.addView(instructionText);top.addView(coverageText);top.addView(coverageBar,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,16).apply{topMargin=4;bottomMargin=5});top.addView(statusText);top.addView(dimensionsText)
        root.addView(top,FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,Gravity.TOP))

        reticle=TextView(this).apply { text="+";setTextColor(0xffcfd8dc.toInt());textSize=48f;gravity=Gravity.CENTER;alpha=0.95f }
        root.addView(reticle,FrameLayout.LayoutParams(100,100,Gravity.CENTER))

        val bottom=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(28,10,28,36);setBackgroundColor(0x77000000) }
        scanButton=Button(this).apply { text="INICIAR ESCANEO";setOnClickListener{toggleScan()} }
        calibrateButton=Button(this).apply { text="CALIBRAR CON CALIBRE";visibility=View.GONE;setOnClickListener{showCalibrationDialog()} }
        exportStlButton=Button(this).apply { text="EXPORTAR STL PARA SLICER";visibility=View.GONE;setOnClickListener{exportModel("stl")} }
        exportPlyButton=Button(this).apply { text="EXPORTAR PLY";visibility=View.GONE;setOnClickListener{exportModel("ply")} }
        val help=TextView(this).apply { text="Guía: VERDE = captura · AMARILLO = cambiá ángulo · NARANJA = más despacio · ROJO = corregí distancia/tracking";setTextColor(0xffeeeeee.toInt());textSize=10.5f;gravity=Gravity.CENTER;setPadding(0,8,0,0) }
        bottom.addView(scanButton);bottom.addView(calibrateButton);bottom.addView(exportStlButton);bottom.addView(exportPlyButton);bottom.addView(help)
        root.addView(bottom,FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,Gravity.BOTTOM))
        setContentView(root)
    }

    private fun updateFeedback(f: ScanRenderer.ScanFeedback) {
        feedbackBadge.text=f.headline
        instructionText.text=f.instruction
        val dist=if(f.distanceMm>0)" · ${f.distanceMm} mm" else ""
        val source=when(f.source){PointCloudFusion.Source.DENSE_DEPTH->"Denso";PointCloudFusion.Source.RAW_DEPTH->"Raw";PointCloudFusion.Source.FEATURE_POINTS->"Visual";else->"—"}
        coverageText.text="Cobertura ${f.coverage}% · ${f.voxels} vóxeles$dist · $source"
        coverageBar.progress=f.coverage
        val color=when(f.quality){
            ScanRenderer.Quality.GOOD->0xff00c853.toInt()
            ScanRenderer.Quality.REPEAT->0xffffc107.toInt()
            ScanRenderer.Quality.FAST->0xffff9800.toInt()
            ScanRenderer.Quality.LOST->0xffff5252.toInt()
            ScanRenderer.Quality.NO_DEPTH->0xff29b6f6.toInt()
            ScanRenderer.Quality.TOO_CLOSE,ScanRenderer.Quality.TOO_FAR->0xffff5252.toInt()
            ScanRenderer.Quality.SEARCHING->0xffffc107.toInt()
            ScanRenderer.Quality.IDLE->0xff607d8b.toInt()
        }
        setBadgeColor(color);reticle.setTextColor(color);coverageBar.progressTintList=ColorStateList.valueOf(color)
        if(f.newSector && f.quality==ScanRenderer.Quality.GOOD)hapticTick()
    }

    private fun setBadgeColor(color:Int){feedbackBadge.background=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;cornerRadius=18f;setColor((color and 0x00ffffff) or 0xdd000000.toInt());setStroke(2,color)}}

    private fun hapticTick(){val now=System.currentTimeMillis();if(now-lastHapticMs<450L)return;lastHapticMs=now;try{val vibrator:Vibrator=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S)getSystemService(VibratorManager::class.java).defaultVibrator else @Suppress("DEPRECATION")(getSystemService(VIBRATOR_SERVICE) as Vibrator);if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)vibrator.vibrate(VibrationEffect.createOneShot(35L,90))else @Suppress("DEPRECATION") vibrator.vibrate(35L)}catch(_:Exception){}}

    private fun toggleScan(){
        if(!renderer.scanning){
            val stamp=SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date());val base=getExternalFilesDir("scans")?:filesDir;currentScanDir=File(base,"scan_$stamp").apply{mkdirs()}
            dimensionsText.visibility=View.GONE;calibrateButton.visibility=View.GONE;exportStlButton.visibility=View.GONE;exportPlyButton.visibility=View.GONE;coverageBar.progress=0;coverageText.text="Cobertura 0% · esperando geometría"
            renderer.beginScan();scanButton.text="DETENER ESCANEO";Toast.makeText(this,"Empezá a 35–70 cm y rodeá la pieza despacio",Toast.LENGTH_LONG).show()
        }else{
            renderer.endScan();scanButton.text="INICIAR ESCANEO";refreshScanSummary(showToast=true)
        }
    }

    private fun refreshScanSummary(showToast:Boolean=false){
        val stats=renderer.stats();val coverage=renderer.coveragePercentNow();val ready=stats.voxels>=350&&coverage>=40
        dimensionsText.text=(if(ready)"✅ LISTO PARA REVISAR/IMPRIMIR" else "⚠️ ESCANEO PARCIAL")+"\nX %.1f · Y %.1f · Z %.1f mm · %d vóxeles · %d%% cobertura · escala ×%.3f".format(stats.widthMm,stats.heightMm,stats.depthMm,stats.voxels,coverage,stats.scaleFactor)
        dimensionsText.visibility=View.VISIBLE
        if(stats.voxels>30){calibrateButton.visibility=View.VISIBLE;exportStlButton.visibility=View.VISIBLE;exportPlyButton.visibility=View.VISIBLE}
        if(showToast)Toast.makeText(this,"${stats.voxels} vóxeles · $coverage% cobertura",Toast.LENGTH_LONG).show()
    }

    private fun showCalibrationDialog(){
        val stats=renderer.stats()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(40,12,40,0)}
        val hint=TextView(this).apply{text="Medidas actuales: X %.1f · Y %.1f · Z %.1f mm\nElegí un eje que puedas medir con calibre.".format(stats.widthMm,stats.heightMm,stats.depthMm);setPadding(0,0,0,12)}
        val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("X","Y","Z"))
        val input=EditText(this).apply{hint="Medida real en mm (ej. 72.35)";inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        box.addView(hint);box.addView(spinner);box.addView(input)
        AlertDialog.Builder(this).setTitle("Calibrar escala").setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("APLICAR"){_,_->
            val mm=input.text.toString().replace(',','.').toFloatOrNull();val axis=spinner.selectedItem.toString().first()
            if(mm==null||!renderer.calibrate(axis,mm))Toast.makeText(this,"Medida inválida",Toast.LENGTH_SHORT).show() else {refreshScanSummary();Toast.makeText(this,"Escala calibrada con eje $axis = $mm mm",Toast.LENGTH_LONG).show()}
        }.show()
    }

    private fun exportModel(format:String){
        val dir=currentScanDir?:return;val points=renderer.pointCount();if(points<30){Toast.makeText(this,"Muy poca geometría. Hacé otro recorrido.",Toast.LENGTH_LONG).show();return}
        val file=File(dir,if(format=="stl")"vector_scan_v13.stl" else "vector_scan_v13.ply")
        statusText.text="Limpiando y generando ${format.uppercase()}…";setExportEnabled(false)
        thread(name="export-$format"){
            try{if(format=="stl")renderer.exportStl(file)else renderer.exportPly(file);runOnUiThread{statusText.text="Archivo listo: ${file.name}";setExportEnabled(true);shareFile(file)}}
            catch(e:Exception){runOnUiThread{statusText.text="Error exportando: ${e.message}";setExportEnabled(true)}}
        }
    }

    private fun setExportEnabled(enabled:Boolean){scanButton.isEnabled=enabled;calibrateButton.isEnabled=enabled;exportStlButton.isEnabled=enabled;exportPlyButton.isEnabled=enabled}
    private fun shareFile(file:File){val uri:Uri=FileProvider.getUriForFile(this,"$packageName.files",file);val mime=if(file.extension.lowercase()=="stl")"model/stl" else "application/octet-stream";startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Compartir ${file.name}"))}

    override fun onResume(){super.onResume();if(hasCameraPermission())startArSession()}
    private fun startArSession(){if(session==null)createSession();try{session?.resume();surfaceView.onResume()}catch(e:CameraNotAvailableException){statusText.text="La cámara no está disponible";session?.close();session=null}}
    private fun createSession(){try{when(ArCoreApk.getInstance().requestInstall(this,!installRequested)){ArCoreApk.InstallStatus.INSTALL_REQUESTED->{installRequested=true;statusText.text="Actualizando Servicios de Google Play para RA…";return};ArCoreApk.InstallStatus.INSTALLED->Unit};session=Session(this).also{s->val config=Config(s);if(s.isDepthModeSupported(Config.DepthMode.AUTOMATIC))config.depthMode=Config.DepthMode.AUTOMATIC;config.focusMode=Config.FocusMode.AUTO;config.updateMode=Config.UpdateMode.LATEST_CAMERA_IMAGE;s.configure(config)}}catch(e:UnavailableException){statusText.text="ARCore no disponible: ${e.javaClass.simpleName}";scanButton.isEnabled=false}catch(e:Exception){statusText.text="No se pudo iniciar ARCore: ${e.message}";scanButton.isEnabled=false}}
    override fun onPause(){super.onPause();surfaceView.onPause();session?.pause()}
    override fun onDestroy(){super.onDestroy();session?.close();session=null}
    private fun hasCameraPermission():Boolean=ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==CAMERA_PERMISSION_CODE){if(grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED)startArSession()else statusText.text="Necesito permiso de cámara para escanear"}}
    companion object{private const val CAMERA_PERMISSION_CODE=1001}
}
