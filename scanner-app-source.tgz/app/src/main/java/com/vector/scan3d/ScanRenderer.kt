package com.vector.scan3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.Anchor
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.io.File
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ScanRenderer(
    private val sessionProvider: () -> Session?,
    private val displayRotationProvider: () -> Int,
    private val onStatus: (String) -> Unit,
    private val onDepthSupport: (Boolean) -> Unit
) : GLSurfaceView.Renderer {

    private lateinit var background: BackgroundRenderer
    private val fusion = PointCloudFusion()
    @Volatile var scanning = false
        private set
    @Volatile private var startRequested = false
    @Volatile private var stopRequested = false
    private var scanAnchor: Anchor? = null
    private var depthEnabled = false
    private var depthChecked = false
    private var surfaceWidth = 1
    private var surfaceHeight = 1
    private var lastStatusMs = 0L

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        background = BackgroundRenderer()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(1)
        surfaceHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, surfaceWidth, surfaceHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session = sessionProvider() ?: return

        try {
            if (!depthChecked) {
                depthEnabled = session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)
                depthChecked = true
                onDepthSupport(depthEnabled)
            }

            session.setDisplayGeometry(displayRotationProvider(), surfaceWidth, surfaceHeight)
            session.setCameraTextureName(background.textureId)
            val frame = session.update()
            background.draw(frame)

            val camera = frame.camera
            if (camera.trackingState != TrackingState.TRACKING) {
                onStatus("Mové el teléfono lentamente para que ARCore ubique la escena")
                return
            }

            if (startRequested) {
                startRequested = false
                fusion.clear()
                scanAnchor?.detach()
                scanAnchor = session.createAnchor(camera.pose)
                scanning = true
                onStatus("Escaneo activo · mantené la pieza en el centro")
            }
            if (stopRequested) {
                stopRequested = false
                scanning = false
            }

            if (!scanning) {
                if (System.currentTimeMillis() - lastStatusMs > 900L) {
                    val count = fusion.pointCount()
                    onStatus(if (count > 0) "Listo · $count vóxeles capturados" else if (depthEnabled) "Listo · Depth activo" else "Listo · modo ARCore")
                    lastStatusMs = System.currentTimeMillis()
                }
                return
            }

            val anchor = scanAnchor ?: return
            val added = if (depthEnabled) {
                fusion.integrateRawDepth(frame, anchor.pose)
            } else {
                fusion.integrateFeaturePoints(frame, anchor.pose)
            }

            if (System.currentTimeMillis() - lastStatusMs > 350L) {
                val count = fusion.pointCount()
                onStatus("Escaneando · +$added · $count vóxeles")
                lastStatusMs = System.currentTimeMillis()
            }
        } catch (e: Exception) {
            onStatus("Error AR: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    fun beginScan() {
        startRequested = true
        stopRequested = false
    }

    fun endScan() {
        stopRequested = true
        scanning = false
    }

    fun isDepthEnabled(): Boolean = depthEnabled
    fun pointCount(): Int = fusion.pointCount()
    fun stats(): PointCloudFusion.Stats = fusion.stats()
    fun exportPly(file: File) = fusion.exportPly(file)
    fun exportStl(file: File) = fusion.exportStl(file)
}
