package com.vector.scan3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.Anchor
import com.google.ar.core.Config
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.io.File
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.sqrt

class ScanRenderer(
    private val sessionProvider: () -> Session?,
    private val displayRotationProvider: () -> Int,
    private val onStatus: (String) -> Unit,
    private val onDepthSupport: (Boolean) -> Unit,
    private val onFeedback: (ScanFeedback) -> Unit
) : GLSurfaceView.Renderer {

    enum class Quality { IDLE, GOOD, REPEAT, FAST, LOST, NO_DEPTH, TOO_CLOSE, TOO_FAR, SEARCHING }

    data class ScanFeedback(
        val quality: Quality,
        val headline: String,
        val instruction: String,
        val coverage: Int,
        val voxels: Int,
        val added: Int,
        val distanceMm: Int = -1,
        val source: PointCloudFusion.Source = PointCloudFusion.Source.NONE,
        val newSector: Boolean = false
    )

    private lateinit var background: BackgroundRenderer
    private val fusion = PointCloudFusion()
    @Volatile var scanning = false
        private set
    @Volatile private var startRequested = false
    @Volatile private var stopRequested = false
    private var scanAnchor: Anchor? = null
    private var depthEnabled = false
    private var depthChecked = false
    private var surfaceWidth = 1
    private var surfaceHeight = 1
    private var lastStatusMs = 0L
    private var lastUsefulGeometryMs = 0L
    private var lastPose: Pose? = null
    private var lastPoseTimestampNs = 0L
    private val visitedSectors = BooleanArray(16)
    private var visitedSectorCount = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        background = BackgroundRenderer()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(1)
        surfaceHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, surfaceWidth, surfaceHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session = sessionProvider() ?: return

        try {
            if (!depthChecked) {
                depthEnabled = session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)
                depthChecked = true
                onDepthSupport(depthEnabled)
            }

            session.setDisplayGeometry(displayRotationProvider(), surfaceWidth, surfaceHeight)
            session.setCameraTextureName(background.textureId)
            val frame = session.update()
            background.draw(frame)

            val camera = frame.camera
            if (camera.trackingState != TrackingState.TRACKING) {
                onStatus("ARCore perdió el seguimiento")
                onFeedback(ScanFeedback(Quality.LOST, "SEGUIMIENTO PERDIDO", "Mové el teléfono despacio hasta recuperar la escena", coveragePercent(), fusion.pointCount(), 0))
                return
            }

            if (startRequested) {
                startRequested = false
                fusion.clear()
                scanAnchor?.detach()
                scanAnchor = session.createAnchor(camera.pose)
                scanning = true
                lastUsefulGeometryMs = System.currentTimeMillis()
                lastPose = null
                lastPoseTimestampNs = 0L
                visitedSectors.fill(false)
                visitedSectorCount = 0
                onStatus("Escaneo de objeto pequeño activo")
                onFeedback(ScanFeedback(Quality.SEARCHING, "BUSCANDO LA PIEZA", "Centrá el objeto y mové el teléfono suavemente de lado a lado", 0, 0, 0))
            }

            if (stopRequested) {
                stopRequested = false
                scanning = false
                onFeedback(ScanFeedback(Quality.IDLE, "ESCANEO DETENIDO", "Revisá cobertura, dimensiones y calibrá antes de exportar", coveragePercent(), fusion.pointCount(), 0, fusion.latestDistanceMm()))
            }

            if (!scanning) {
                if (System.currentTimeMillis() - lastStatusMs > 900L) {
                    val count = fusion.pointCount()
                    onStatus(if (count > 0) "Listo · $count vóxeles" else if (depthEnabled) "Listo · Depth denso disponible" else "Listo · sin Depth")
                    lastStatusMs = System.currentTimeMillis()
                }
                return
            }

            val anchor = scanAnchor ?: return
            val speedMps = estimateSpeed(camera.pose, frame.timestamp)
            val result = fusion.integrateHybridDepth(frame, anchor.pose)

            val now = System.currentTimeMillis()
            if (result.added > 0) lastUsefulGeometryMs = now
            val newSector = if (result.added > 0) updateCoverage(camera.pose, anchor.pose) else false
            val count = fusion.pointCount()
            val coverage = coveragePercent()
            val distance = result.distanceMm

            val feedback = when {
                speedMps > 0.45f -> ScanFeedback(Quality.FAST, "MOVIMIENTO RÁPIDO", "Más despacio: así el detalle queda mejor registrado", coverage, count, result.added, distance, result.source, newSector)
                distance in 1..279 -> ScanFeedback(Quality.TOO_CLOSE, "DEMASIADO CERCA", "Alejate un poco. Objetivo: 35–70 cm", coverage, count, result.added, distance, result.source, newSector)
                distance > 900 -> ScanFeedback(Quality.TOO_FAR, "DEMASIADO LEJOS", "Acercate. Objetivo: 35–70 cm", coverage, count, result.added, distance, result.source, newSector)
                !depthEnabled -> ScanFeedback(Quality.NO_DEPTH, "SIN DEPTH", "La app usa puntos visuales; movete muy lento y con buena luz", coverage, count, result.added, distance, result.source, newSector)
                result.added > 0 -> ScanFeedback(Quality.GOOD, "CAPTURANDO GEOMETRÍA", if (newSector) "Nueva vista registrada ✓" else "Seguí rodeando el objeto lentamente", coverage, count, result.added, distance, result.source, newSector)
                distance <= 0 && now - lastUsefulGeometryMs > 650L -> ScanFeedback(Quality.SEARCHING, "BUSCANDO PROFUNDIDAD", "Mové el teléfono 5–10 cm de lado a lado sin sacar la pieza del centro", coverage, count, 0, distance, result.source, newSector)
                now - lastUsefulGeometryMs > 1100L -> ScanFeedback(Quality.REPEAT, "SIN GEOMETRÍA NUEVA", "Cambiá de ángulo manteniendo la misma distancia", coverage, count, 0, distance, result.source, newSector)
                else -> ScanFeedback(Quality.GOOD, "ESCANEANDO", "Mantené el objeto centrado y avanzá despacio", coverage, count, 0, distance, result.source, newSector)
            }

            if (now - lastStatusMs > 220L || newSector) {
                onFeedback(feedback)
                val d = if (distance > 0) " · ${distance}mm" else ""
                onStatus("${feedback.headline} · ${feedback.coverage}% · ${feedback.voxels} vóxeles$d")
                lastStatusMs = now
            }
        } catch (e: Exception) {
            onStatus("Error AR: ${e.message ?: e.javaClass.simpleName}")
            onFeedback(ScanFeedback(Quality.LOST, "ERROR DE CAPTURA", "Volvé a apuntar al objeto lentamente", coveragePercent(), fusion.pointCount(), 0))
        }
    }

    private fun estimateSpeed(pose: Pose, timestampNs: Long): Float {
        val previous=lastPose; val previousTs=lastPoseTimestampNs
        lastPose=pose; lastPoseTimestampNs=timestampNs
        if(previous==null||previousTs<=0L||timestampNs<=previousTs)return 0f
        val dt=(timestampNs-previousTs)/1_000_000_000f
        if(dt<=0f||dt>0.5f)return 0f
        val dx=pose.tx()-previous.tx();val dy=pose.ty()-previous.ty();val dz=pose.tz()-previous.tz()
        return sqrt(dx*dx+dy*dy+dz*dz)/dt
    }

    private fun updateCoverage(cameraPose:Pose, anchorPose:Pose):Boolean {
        val target=fusion.targetPositionInAnchor() ?: return false
        val cameraInAnchor=anchorPose.inverse().transformPoint(floatArrayOf(cameraPose.tx(),cameraPose.ty(),cameraPose.tz()))
        val dx=cameraInAnchor[0]-target[0]; val dz=cameraInAnchor[2]-target[2]
        if(dx*dx+dz*dz<0.0025f)return false
        var angle=atan2(dx.toDouble(),dz.toDouble())+PI
        if(angle<0.0)angle+=2.0*PI
        if(angle>=2.0*PI)angle-=2.0*PI
        val sector=((angle/(2.0*PI))*visitedSectors.size).toInt().coerceIn(0,visitedSectors.lastIndex)
        if(!visitedSectors[sector]){visitedSectors[sector]=true;visitedSectorCount++;return true}
        return false
    }

    private fun coveragePercent():Int=((visitedSectorCount*100f)/visitedSectors.size).toInt().coerceIn(0,100)

    fun beginScan(){startRequested=true;stopRequested=false}
    fun endScan(){stopRequested=true;scanning=false}
    fun pointCount():Int=fusion.pointCount()
    fun stats():PointCloudFusion.Stats=fusion.stats()
    fun coveragePercentNow():Int=coveragePercent()
    fun exportPly(file:File)=fusion.exportPly(file)
    fun exportStl(file:File)=fusion.exportStl(file)
    fun calibrate(axis:Char,actualMm:Float):Boolean=fusion.calibrate(axis,actualMm)
}
