package com.vector.scan3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.Anchor
import com.google.ar.core.Config
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.io.File
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.sqrt

class ScanRenderer(
    private val sessionProvider: () -> Session?,
    private val displayRotationProvider: () -> Int,
    private val onStatus: (String) -> Unit,
    private val onDepthSupport: (Boolean) -> Unit,
    private val onFeedback: (ScanFeedback) -> Unit
) : GLSurfaceView.Renderer {

    enum class Quality { IDLE, GOOD, REPEAT, FAST, LOST, NO_DEPTH }

    data class ScanFeedback(
        val quality: Quality,
        val headline: String,
        val instruction: String,
        val coverage: Int,
        val voxels: Int,
        val added: Int,
        val newSector: Boolean = false
    )

    private lateinit var background: BackgroundRenderer
    private val fusion = PointCloudFusion()
    @Volatile var scanning = false
        private set
    @Volatile private var startRequested = false
    @Volatile private var stopRequested = false
    private var scanAnchor: Anchor? = null
    private var depthEnabled = false
    private var depthChecked = false
    private var surfaceWidth = 1
    private var surfaceHeight = 1
    private var lastStatusMs = 0L
    private var lastUsefulGeometryMs = 0L
    private var lastPose: Pose? = null
    private var lastPoseTimestampNs = 0L
    private val visitedSectors = BooleanArray(12)
    private var visitedSectorCount = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        background = BackgroundRenderer()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = width.coerceAtLeast(1)
        surfaceHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, surfaceWidth, surfaceHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session = sessionProvider() ?: return

        try {
            if (!depthChecked) {
                depthEnabled = session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)
                depthChecked = true
                onDepthSupport(depthEnabled)
            }

            session.setDisplayGeometry(displayRotationProvider(), surfaceWidth, surfaceHeight)
            session.setCameraTextureName(background.textureId)
            val frame = session.update()
            background.draw(frame)

            val camera = frame.camera
            if (camera.trackingState != TrackingState.TRACKING) {
                onStatus("ARCore perdió el seguimiento")
                onFeedback(
                    ScanFeedback(
                        Quality.LOST,
                        "SEGUIMIENTO PERDIDO",
                        "Mové el teléfono lentamente hasta recuperar la escena",
                        coveragePercent(), fusion.pointCount(), 0
                    )
                )
                return
            }

            if (startRequested) {
                startRequested = false
                fusion.clear()
                scanAnchor?.detach()
                scanAnchor = session.createAnchor(camera.pose)
                scanning = true
                lastUsefulGeometryMs = System.currentTimeMillis()
                lastPose = null
                lastPoseTimestampNs = 0L
                visitedSectors.fill(false)
                visitedSectorCount = 0
                onStatus("Escaneo activo")
                onFeedback(ScanFeedback(Quality.GOOD, "ESCANEO INICIADO", "Mantené la pieza en la cruz y empezá a rodearla", 0, 0, 0))
            }
            if (stopRequested) {
                stopRequested = false
                scanning = false
                onFeedback(
                    ScanFeedback(
                        Quality.IDLE,
                        "ESCANEO DETENIDO",
                        "Revisá la cobertura y exportá cuando estés conforme",
                        coveragePercent(), fusion.pointCount(), 0
                    )
                )
            }

            if (!scanning) {
                if (System.currentTimeMillis() - lastStatusMs > 900L) {
                    val count = fusion.pointCount()
                    onStatus(if (count > 0) "Listo · $count vóxeles capturados" else if (depthEnabled) "Listo · Depth activo" else "Listo · modo ARCore")
                    lastStatusMs = System.currentTimeMillis()
                }
                return
            }

            val anchor = scanAnchor ?: return
            val speedMps = estimateSpeed(camera.pose, frame.timestamp)
            val added = if (depthEnabled) {
                fusion.integrateRawDepth(frame, anchor.pose)
            } else {
                fusion.integrateFeaturePoints(frame, anchor.pose)
            }
            val now = System.currentTimeMillis()
            if (added > 0) lastUsefulGeometryMs = now
            val newSector = updateCoverage(camera.pose, anchor.pose)
            val count = fusion.pointCount()
            val coverage = coveragePercent()

            val feedback = when {
                speedMps > 0.55f -> ScanFeedback(
                    Quality.FAST,
                    "MOVIMIENTO RÁPIDO",
                    "Bajá la velocidad para no perder detalle",
                    coverage, count, added, newSector
                )
                !depthEnabled -> ScanFeedback(
                    Quality.NO_DEPTH,
                    "ESCANEANDO SIN DEPTH",
                    "Funciona, pero movete lento y mantené buena textura e iluminación",
                    coverage, count, added, newSector
                )
                added > 0 -> ScanFeedback(
                    Quality.GOOD,
                    "ESCANEANDO BIEN",
                    if (newSector) "Nueva zona capturada ✓" else "Seguí rodeando la pieza lentamente",
                    coverage, count, added, newSector
                )
                now - lastUsefulGeometryMs > 1200L -> ScanFeedback(
                    Quality.REPEAT,
                    "SIN GEOMETRÍA NUEVA",
                    "Cambiá de ángulo o acercate un poco a la pieza",
                    coverage, count, 0, newSector
                )
                else -> ScanFeedback(
                    Quality.GOOD,
                    "ESCANEANDO",
                    "Mantené la pieza centrada y seguí despacio",
                    coverage, count, 0, newSector
                )
            }

            if (now - lastStatusMs > 250L || newSector) {
                onFeedback(feedback)
                onStatus("${feedback.headline} · ${feedback.coverage}% · ${feedback.voxels} vóxeles")
                lastStatusMs = now
            }
        } catch (e: Exception) {
            onStatus("Error AR: ${e.message ?: e.javaClass.simpleName}")
            onFeedback(ScanFeedback(Quality.LOST, "ERROR DE CAPTURA", "Volvé a apuntar a la pieza lentamente", coveragePercent(), fusion.pointCount(), 0))
        }
    }

    private fun estimateSpeed(pose: Pose, timestampNs: Long): Float {
        val previous = lastPose
        val previousTs = lastPoseTimestampNs
        lastPose = pose
        lastPoseTimestampNs = timestampNs
        if (previous == null || previousTs <= 0L || timestampNs <= previousTs) return 0f
        val dt = (timestampNs - previousTs) / 1_000_000_000f
        if (dt <= 0f || dt > 0.5f) return 0f
        val dx = pose.tx() - previous.tx()
        val dy = pose.ty() - previous.ty()
        val dz = pose.tz() - previous.tz()
        return sqrt(dx*dx + dy*dy + dz*dz) / dt
    }

    private fun updateCoverage(cameraPose: Pose, anchorPose: Pose): Boolean {
        val target = fusion.targetPositionInAnchor() ?: return false
        val worldToAnchor = anchorPose.inverse()
        val cameraInAnchor = worldToAnchor.transformPoint(floatArrayOf(cameraPose.tx(), cameraPose.ty(), cameraPose.tz()))
        val dx = cameraInAnchor[0] - target[0]
        val dz = cameraInAnchor[2] - target[2]
        if (dx*dx + dz*dz < 0.0025f) return false
        var angle = atan2(dx.toDouble(), dz.toDouble()) + PI
        if (angle < 0.0) angle += 2.0 * PI
        if (angle >= 2.0 * PI) angle -= 2.0 * PI
        val sector = ((angle / (2.0 * PI)) * visitedSectors.size).toInt().coerceIn(0, visitedSectors.lastIndex)
        if (!visitedSectors[sector]) {
            visitedSectors[sector] = true
            visitedSectorCount++
            return true
        }
        return false
    }

    private fun coveragePercent(): Int = ((visitedSectorCount * 100f) / visitedSectors.size).toInt().coerceIn(0, 100)

    fun beginScan() {
        startRequested = true
        stopRequested = false
    }

    fun endScan() {
        stopRequested = true
        scanning = false
    }

    fun isDepthEnabled(): Boolean = depthEnabled
    fun pointCount(): Int = fusion.pointCount()
    fun stats(): PointCloudFusion.Stats = fusion.stats()
    fun coveragePercentNow(): Int = coveragePercent()
    fun exportPly(file: File) = fusion.exportPly(file)
    fun exportStl(file: File) = fusion.exportStl(file)
}
